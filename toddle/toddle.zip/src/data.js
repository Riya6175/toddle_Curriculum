export  let data = [
    {
        id: 1,
        title: "Linear Algebra",
        subtitle: [
            {
                "id": 2,
                "title": "variable",
            },
            {
                "id": 3,
                "title": "variable-2",
            },
        ]
    },
    {
        id: 4,
        title: "Calculus",
        subtitle: [
            {
                "id": 5,
                "title": "variable-3",
            },
    
        ]
    },
]