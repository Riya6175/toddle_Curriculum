import React from 'react';
import './App.css';
import Parent_component from './components/parent_component/Parent_component';


function App() {
  return (
    <div className="App">
      <Parent_component/>
    </div>
  );
}

export default App;
